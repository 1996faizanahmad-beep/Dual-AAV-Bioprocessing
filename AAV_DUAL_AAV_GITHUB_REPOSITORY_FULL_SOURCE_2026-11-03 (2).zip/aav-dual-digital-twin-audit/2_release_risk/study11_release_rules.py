#!/usr/bin/env python3
"""Study 11 rerun with a stated seed and SAVED per-lot classifications.
Inputs: study7_process_to_product_mc.csv (30,000 lots; columns qVG..., normalised_function [fraction units], total_VG_index).
Rules (manuscript Sec 2.15): titre (8% CV), full fraction (7% CV), titre x full fraction, functional assay (10% CV; R replicates, log-normal error).
Acceptance: the same share of lots under every rule. Good lot: true function >= 3.30% (60% of 5.50%).
Measurement noise: mean-preserving log-normal, sigma^2 = ln(1+CV^2); replicates averaged arithmetically (ASSUMPTION: the manuscript does not state how replicates were combined)."""
import numpy as np, pandas as pd, sys, argparse
SPEC = 0.033
def noise(rng, cv, size):
    s = np.sqrt(np.log(1+cv**2)); return np.exp(rng.normal(-s**2/2, s, size))
def auc(score, good):
    r = pd.Series(score).rank().values; n1 = good.sum(); n0 = len(good)-n1
    return (r[good].sum() - n1*(n1+1)/2)/(n1*n0)
def run(d, seed, accept, reps=(1, 2, 3, 6, 12), save=None):
    rng = np.random.default_rng(seed); n = len(d); f = d.normalised_function.values; vg = d.total_VG_index.values; F = d.full_fraction.values
    good = f >= SPEC; scores = {"titre": vg*noise(rng, .08, n), "full_fraction": F*noise(rng, .07, n), "titre_x_fraction": vg*noise(rng, .08, n)*F*noise(rng, .07, n)}
    for R in reps: scores["function_x%d" % R] = f*noise(rng, .10, (R, n)).mean(0)
    out = {}; rows = []
    for k, s in scores.items():
        thr = np.quantile(s, 1-accept); rel = s >= thr; out[k] = dict(AUC=auc(s, good), consumer_risk=100*(~good[rel]).mean(), accepted=int(rel.sum()))
        if save: rows.append(pd.DataFrame(dict(lot_id=np.arange(n), scheme=k, truly_out_of_spec=(~good).astype(int), released=rel.astype(int), score=s)))
    if save: pd.concat(rows).to_csv(save, index=False)
    return out, good.mean()
if __name__ == "__main__":
    ap = argparse.ArgumentParser(); ap.add_argument("--seed", type=int, default=20261027); ap.add_argument("--accept", type=float, default=None); ap.add_argument("--save", default=None); a = ap.parse_args()
    d = pd.read_csv("study7_process_to_product_mc.csv"); out, prev = run(d, a.seed, a.accept if a.accept else None or 0.5, save=a.save)
    print("share of good lots (function >= 3.30%%): %.1f%%" % (100*prev))
    for k, v in out.items(): print("  %-17s AUC %.3f  consumer risk %5.1f%%  (accepted %d)" % (k, v["AUC"], v["consumer_risk"], v["accepted"]))
