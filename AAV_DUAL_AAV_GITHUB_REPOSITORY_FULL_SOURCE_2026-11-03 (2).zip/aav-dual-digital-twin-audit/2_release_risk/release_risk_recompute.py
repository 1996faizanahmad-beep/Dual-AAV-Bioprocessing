#!/usr/bin/env python3
"""Item: recompute consumer risk ONCE from saved lot classifications.
Usage: python3 release_risk_recompute.py lots.csv
Expected columns (adapt names if your file differs): lot_id, scheme (1rep|3rep), truly_out_of_spec (0/1), released (0/1)
Consumer risk = P(truly out-of-spec | released) per scheme. Prints one table; delete all other quoted values."""
import csv, sys, collections, random, os, tempfile
def selftest():
    rng = random.Random(0); path = os.path.join(tempfile.gettempdir(), "lots_selftest.csv")
    with open(path, "w", newline="") as f:
        w = csv.writer(f); w.writerow(["lot_id", "scheme", "truly_out_of_spec", "released"])
        for i in range(1000):
            bad = int(rng.random() < 0.2)
            for sch, pr in (("1rep", 0.30), ("3rep", 0.10)):
                rel = int(rng.random() < (pr if bad else 0.9)); w.writerow([i, sch, bad, rel])
    return path
if sys.argv[1] == "--selftest": sys.argv[1] = selftest(); print("SELFTEST on synthetic lots (not study data)")
n = collections.Counter(); bad = collections.Counter()
for r in csv.DictReader(open(sys.argv[1])):
    if r["released"] == "1":
        n[r["scheme"]] += 1; bad[r["scheme"]] += int(r["truly_out_of_spec"])
for s in sorted(n): print(f"{s}: released={n[s]} out-of-spec among released={bad[s]} consumer_risk={bad[s]/n[s]:.4%}")
