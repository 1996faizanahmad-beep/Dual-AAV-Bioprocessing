# Study 11 release-rule risk: regenerated with saved lot classifications (2026-10-26)
Input: study7_process_to_product_mc.csv, SHA-256 f43ce02b5e5142885037115c89cfb61105955d9a38e0657e7e528f49bcca4d32. It was taken from the Paper B repository's eight-studies result folder. Its correlations match the Paper A PDF, but I could not byte-compare it with the Paper A archive (not uploaded here): compare this hash with data/eight_studies_results/study7_process_to_product_mc.csv in 3_GitHub_Repository_aav-dual-digital-twin.zip.
Run:
  python3 study11_release_rules.py --seed 20261027 --accept 0.5457333333333333 --save lot_classifications_seed20261027.csv
  python3 release_risk_recompute.py lot_classifications_seed20261027.csv        # one consumer-risk table from the saved file
Results (50 noise seeds): study11_summary_50_noise_seeds.csv ; figure: ../figures/Figure8bd_release_rules.* (regenerate with ../figures/make_figures.py) ; decisions and manuscript text: the publication package (07_study11_and_3.09_decisions.md)
Assumptions NOT stated in the manuscript: mean-preserving log-normal noise; replicates averaged arithmetically; acceptance share = share of lots meeting specification (this reproduces the PDF's 32.4% and 36.0% exactly).
Not verified: that this reproduces the original run's random numbers (impossible: original seeds were not saved); only that the same design gives the same results within Monte Carlo error.
