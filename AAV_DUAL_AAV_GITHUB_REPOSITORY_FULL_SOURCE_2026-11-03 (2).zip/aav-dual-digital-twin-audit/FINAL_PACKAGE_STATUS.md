# Final consolidated package status — 3 November 2026

**PRIVATE REVIEW PACKAGE — NOT CLEARED FOR PUBLIC GITHUB RELEASE OR JOURNAL SUBMISSION.**

This repository snapshot is retained as a computational audit workspace. Its public test suite passed 6/6 tests when run during package assembly. Passing tests verifies only the tested code paths; it does not validate biological assumptions, experimental performance, or every manuscript figure/table.

## Relationship to the master manuscript
The master manuscript is `01_MASTER_MANUSCRIPT/AAV_Modular_Dual_AAV_Manuscript_EDITORIAL_REPAIR_v2.docx` in the parent package. That editorial-repair version conservatively removes unsupported AUC and other unreconciled claims. The repository still contains Study 11 scripts/data and legacy figure assets. These must not be reintroduced into the manuscript until a version-locked crosswalk proves that exact inputs, scripts, seeds, outputs, figure panels, captions, and manuscript statements agree.

## Mandatory release restrictions
1. The upstream Nguyen et al. source repository is CC BY-ND 4.0. The adapted Python port is not included in this repository. Do not publish or redistribute it without written permission.
2. The permission request was drafted on 2026-10-26 and was **not yet sent** according to `docs/PERMISSION_STATUS.md`.
3. Historical 8D SSR 0.731223 is unrecovered. The frozen 0.668084 fit is a distinct run and must not be represented as the historical fit.
4. Study 6 legacy observations and their historical inference provenance remain unresolved. Synthetic method demonstrations are not biological data.
5. Study 11 release-risk/AUC/consumer-risk metrics and the retained release-risk figure assets are audit material only until their source-data provenance and manuscript correspondence are established.
6. MCMC/UKF/PI-control claims, A:B tolerance claims, and any other version-mismatched numerical claims must remain excluded unless regenerated and independently cross-checked.
7. The license scope, author metadata, references, repository URL, archival DOI, figure/table provenance, and declarations require author confirmation.

## Public release decision
Do not push this snapshot to a public GitHub repository or create a public release/tag yet. Keep it private during cleanup. No GitHub push was performed as part of this package assembly.
