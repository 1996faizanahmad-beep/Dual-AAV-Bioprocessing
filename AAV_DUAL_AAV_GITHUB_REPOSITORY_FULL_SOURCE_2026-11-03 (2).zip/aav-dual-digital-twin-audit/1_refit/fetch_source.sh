#!/bin/sh
# Fetch the ORIGINAL authors' repository at the exact commit used here (license: CC BY-ND 4.0, see note in README_REFIT.md)
git clone https://github.com/tamntnguyen/AAV-Triple-Transfection-Mechanistic-Model nguyen_src
(cd nguyen_src && git checkout 4e7fb16c59ef2ca526618feca7fc8b25de79c65d)
cp -r nguyen_src/Data nguyen_src/model_params.mat .
