#!/usr/bin/env python3
"""Refine the best multistart candidates to convergence (needs the private port). Reads multistart_best_1.json, writes refined_best.json and prints the best 8D fit."""
import json, numpy as np
from scipy.optimize import least_squares
import refit8d as R
res = []
for ssr0, q in json.load(open("multistart_best_1.json"))[:3]:
    f = least_squares(R.res, np.array(q), method="trf", diff_step=1e-4, xtol=1e-12, ftol=1e-12, gtol=1e-12, max_nfev=100)
    res.append(((f.fun**2).sum(), list(f.x))); print("refined %.4f -> %.6f (nfev %d)" % (ssr0, res[-1][0], f.nfev))
res.sort(key=lambda a: a[0]); json.dump(res, open("refined_best.json", "w"))
s, q = res[0]; print("BEST SSR %.6f RMSE %.6f" % (s, np.sqrt(s/31)))
for n, a, b in zip(R.NAMES, R.K0[R.FREE], 10**np.array(q)): print("  %-15s source %.4e -> fit %.4e (x%.3g)" % (n, a, b, b/a))
