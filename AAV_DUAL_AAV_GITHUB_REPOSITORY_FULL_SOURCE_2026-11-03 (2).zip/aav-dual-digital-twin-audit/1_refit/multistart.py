import numpy as np, time, json, sys
from scipy.optimize import least_squares
import refit8d as R
rng = np.random.default_rng(int(sys.argv[1])); T0 = time.time(); LIM = float(sys.argv[2]); out = []
while time.time()-T0 < LIM:
    s = R.q0 + rng.normal(0, float(sys.argv[3]), 8)
    try:
        t = time.time(); r = R.res(s)
        if time.time()-t > 3 or not np.isfinite(r).all(): continue
        f = least_squares(lambda q: R.res(q), s, method="trf", diff_step=1e-3, xtol=1e-9, ftol=1e-9, gtol=1e-9, max_nfev=30)
        out.append(((f.fun**2).sum(), list(f.x)))
        print("SSR %.4f (start %.2f)  t=%.0fs" % (out[-1][0], (r**2).sum(), time.time()-T0), flush=True); json.dump(sorted(out, key=lambda a: a[0])[:6], open("multistart_best_%s.json" % sys.argv[1], "w"))
    except Exception as e: pass
out.sort(key=lambda a: a[0]); json.dump(out[:5], open("multistart_best_%s.json" % sys.argv[1], "w"))
print("BEST", out[0][0] if out else None)
