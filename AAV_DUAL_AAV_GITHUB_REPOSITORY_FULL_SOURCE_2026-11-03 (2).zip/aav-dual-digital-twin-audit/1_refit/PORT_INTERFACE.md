# nguyen_port.py is intentionally NOT included
The original model (github.com/tamntnguyen/AAV-Triple-Transfection-Mechanistic-Model, commit 4e7fb16c59ef2ca526618feca7fc8b25de79c65d) is licensed CC BY-ND 4.0, which does not allow sharing adapted material. My Python port is an adaptation, so it is withheld until the authors give written permission (request drafted, not yet sent: see PERMISSION_STATUS.md).
The scripts here import it and expect this interface (so anyone with permission, or a licensed MATLAB/Octave bridge, can supply it):
  kAll() -> 14 parameters;  load() -> list of (observable 'dna'|'full'|'cap', time_h, value) from Data/*.mat;
  simulate(k, times, x0=7.6e4, rtol, atol, method) -> per-mL states (n_times x 21);  observables(X) -> dict(dna, full, cap);  residuals(k, pts, **kw) -> log10(model/obs).
What IS public and checkable now: the frozen fit vector, residual definition, SSR, singular values, profiles (fit8d_FROZEN.json, weak_eta_profiles_REGENERATED.csv), all hashes, and the exact upstream commit to fetch.
