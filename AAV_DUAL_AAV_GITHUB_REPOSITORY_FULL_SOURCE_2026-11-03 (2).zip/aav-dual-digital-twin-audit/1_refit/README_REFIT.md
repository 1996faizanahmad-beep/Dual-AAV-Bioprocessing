# 8D refit of the Nguyen 21-state AAV model — regenerated, frozen, reproducible
Source: github.com/tamntnguyen/AAV-Triple-Transfection-Mechanistic-Model, commit 4e7fb16c59ef2ca526618feca7fc8b25de79c65d (30 Jul 2021). Executed 2026-10-26.

## Reproduce (about 10 minutes, plain Python: numpy, scipy, matplotlib)
sh fetch_source.sh                       # original data + published parameters
python3 refit8d.py 0                     # start = source values; prints SSR 3.114402
python3 multistart.py 1 100 0.8          # seed 1; finds basins 0.678-2.26
python3 refine_best.py                # refine the best candidates -> refined_best.json (SSR 0.668084)
python3 weak_profiles.py 7 ; python3 weak_profiles.py 6 5     # profiles start at q_fit.npy (frozen vector)
Frozen vector, residual definition, solver and seed: fit8d_FROZEN.json.

## What was verified
1. Port reproduces manuscript Table 2: total DNA and total capsid within 0.08% / 0.04% at all four times (source-like tolerances); full virions within 0.3% at 24-46 h but 2.7% LOWER at 10 h (1.557e7 vs 1.6005e7). Forward 46 h audit reproduces: DNA -14.3%, full +44.8% (manuscript +44.7%), capsid -6.3%.
2. Residual definition: 31 source points (12 DNA, 10 capsid, 9 full), log10(model/data), unweighted. 0.731223 / 0.153583^2 = 31.0 exactly supports N = 31.
3. Source parameters give SSR 3.1144, NOT the manuscript's 1.7434. 2.893 of that 3.114 comes from the two 10 h capsid points: the source model overshoots them 15.9x (9.32e9 vs 5.85e8). No simple variant I tried (ln, relative, replicate means, excluding 10 h) gives 1.7434.
4. 8D refit best SSR 0.668084 (RMSE 0.146803), identical on BDF, Radau and LSODA (rtol 1e-6/1e-8); 0.668410 at source-like rtol 1e-2. Other local minima: 0.687, 0.704, 2.2 (stalled basin). So the objective is multimodal; the manuscript's 0.731223 lies in the same range but cannot be reproduced exactly (its vector was never saved).
5. Profiles started at the frozen vector have baseline 0.668084 by construction (no 0.731 vs 0.819 conflict).

## Things you must know
- The fitted vector is far from the source values (kPack x1500, kRepCapSyn x0.049, kBindRCplasmid x0.0097) — a direct symptom of the weak directions. The 8D fit is a descriptive reduction, not a biological parameter estimate; with this fit the 46 h full/total fraction is 3.70% (source params: 3.09%) and full virions at 46 h are +52% above observation.
- LICENSE: the original repository is CC BY-ND 4.0 (NoDerivatives). nguyen_port.py is a line-by-line Python port, i.e. adapted material. Keep it private, or ask Prof. Braatz's group for written permission before publishing it. The public repo should instead cite the original commit and say how to fetch it. I am not a lawyer.
- diego3862/Python-AAV-Triple-Transfection-Mechanistic-Model on GitHub is an unrelated third-party port that I did NOT use.

## End-to-end verification (executed from a clean directory, 2026-10-26)
`python3 verify_reproduction.py` -> ALL PASS (see VERIFY_LOG.txt): source-input SHA-256 match, Table 2 DNA/capsid within 0.1%, source SSR 3.1144, frozen SSR 0.668084,
refinement from the stored start reaches 0.668084 (11 s), profile v8 matches the stored CSV exactly. Versions: Python 3.12.3, numpy 2.4.4, scipy 1.17.1.
The upstream Data/ and model_params.mat are NOT bundled here: run fetch_source.sh to download them from the original repository at the pinned commit.
Limit: the random multistart discovery step (multistart.py) is not guaranteed bit-identical on other library versions; refinement and profiles from the stored vectors are.
Still not established: that 0.731223 or 4.0864e4 from the earlier draft can be reproduced (the original vector was never saved), and independent confirmation by someone other than the author.
