"""Weak-direction profiles started at the SAME frozen 8D vector (q_fit.npy). For each weak singular direction v_w (log10 coordinates) and fixed step xi,
minimise SSR over the 7 coordinates orthogonal to v_w, warm-started outward from xi = 0. Baseline row (xi=0) is the frozen-fit SSR by construction."""
import numpy as np, csv, time, sys
from scipy.optimize import least_squares
import refit8d as R
q = np.load("q_fit.npy"); J = np.load("J8_fit.npy"); _, S, Vt = np.linalg.svd(J, full_matrices=False)
XI = [0.0, 0.1, 0.25, 0.5, 1.0]; rows = []; T0 = time.time()
for w in (int(a) for a in sys.argv[1:]):
    v = Vt[w]; Q, _ = np.linalg.qr(np.column_stack([v, np.eye(8)])); B = Q[:, 1:8]      # orthonormal complement of v
    for sign in (+1, -1):
        c = np.zeros(7)
        for xi in XI:
            if sign == -1 and xi == 0: continue
            f = lambda cc: R.res(q + sign*xi*v + B @ cc)
            fit = least_squares(f, c, method="trf", diff_step=1e-4, xtol=1e-10, ftol=1e-10, gtol=1e-10, max_nfev=25); c = fit.x
            rows.append([w+1, round(float(S[w]), 5), sign*xi, float((fit.fun**2).sum())]); print("v%d xi=%+.2f SSR %.6f  (%.0fs)" % (w+1, sign*xi, rows[-1][3], time.time()-T0), flush=True)
with open("weak_profiles_part_%s.csv" % "_".join(sys.argv[1:]), "w", newline="") as fh:
    wr = csv.writer(fh); wr.writerow(["direction", "singular_value", "xi_log10_units", "SSR_after_reoptimisation"]); wr.writerows(rows)
