#!/usr/bin/env python3
"""End-to-end check from source inputs. Run from this folder after fetch_source.sh (or with the bundled Data/ and model_params.mat).
1 hash check of source inputs  2 Table 2 reproduction  3 frozen SSR  4 refine from stored start  5 weak-direction profile v8 vs stored CSV."""
import hashlib, json, csv, sys, numpy as np, scipy, time
from scipy.optimize import least_squares
import refit8d as R
from nguyen_port import *
ok = True
def chk(name, cond, detail=""):
    global ok; ok &= bool(cond); print("%-6s %s %s" % ("PASS" if cond else "FAIL", name, detail), flush=True)
exp = dict(l.split()[::-1] for l in open("SOURCE_INPUT_SHA256.txt"))
for f, h in exp.items(): chk("sha256 " + f, hashlib.sha256(open(f, "rb").read()).hexdigest() == h)
k = kAll(); ob = observables(simulate(k, [10, 24, 34, 46], rtol=1e-8, atol=1e-3, method="LSODA"))
man = dict(dna=[5.5909e8, 1.2610e9, 2.4875e9, 4.1233e9], cap=[9.3210e9, 2.9514e10, 4.0549e10, 5.0923e10])
for n in man: chk("Table 2 " + n + " within 0.1%", max(abs(a/b-1) for a, b in zip(ob[n], man[n])) < 1e-3)
fz = json.load(open("fit8d_FROZEN.json")); q = np.array(fz["log10_theta"]); s = (R.res(q)**2).sum()
chk("frozen SSR", abs(s-fz["SSR"]) < 1e-5, "%.6f" % s)
chk("source-parameter SSR 3.1144", abs((R.res(R.q0)**2).sum()-3.1144) < 1e-3)
st = json.load(open("multistart_best_1.json"))[0][1]; t = time.time()
f = least_squares(R.res, np.array(st), method="trf", diff_step=1e-4, xtol=1e-12, ftol=1e-12, gtol=1e-12, max_nfev=100)
chk("refinement from stored start reaches <=0.669", (f.fun**2).sum() < 0.669, "SSR %.6f (%.0fs)" % ((f.fun**2).sum(), time.time()-t))
J = np.load("J8_fit.npy"); _, S, Vt = np.linalg.svd(J, full_matrices=False); v = Vt[7]; B = np.linalg.qr(np.column_stack([v, np.eye(8)]))[0][:, 1:8]
stored = {float(r["xi_log10_units"]): float(r["SSR_after_reoptimisation"]) for r in csv.DictReader(open("weak_eta_profiles_REGENERATED.csv")) if int(r["weak_direction_v"]) == 8}
c = np.zeros(7); worst = 0
for xi in (0.0, 0.25, 0.5):
    g = least_squares(lambda cc: R.res(q+xi*v+B@cc), c, method="trf", diff_step=1e-4, xtol=1e-10, ftol=1e-10, gtol=1e-10, max_nfev=25); c = g.x
    worst = max(worst, abs((g.fun**2).sum()-stored[xi]))
chk("profile v8 reproduces stored CSV (max |dSSR| < 2e-4)", worst < 2e-4, "max diff %.2e" % worst)
print("versions: python %s numpy %s scipy %s" % (sys.version.split()[0], np.__version__, scipy.__version__)); print("ALL PASS" if ok else "SOME CHECKS FAILED")
