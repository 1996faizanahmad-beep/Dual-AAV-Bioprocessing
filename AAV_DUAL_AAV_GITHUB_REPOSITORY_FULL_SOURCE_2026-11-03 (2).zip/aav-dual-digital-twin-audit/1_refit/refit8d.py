"""8D refit of the Nguyen model (source-constrained), log10 residuals over all 31 source points.
Free (p1..p8): kUptake, kNuclearEntry, kPlasmidDeg, common Rep/Cap synthesis (kRepSyn=kCapSyn), kDNArep, kBindRCplasmid, kBindCapsid, kPack.
Fixed at source: kEscape, kProteinDegRep, kProteinDegCap, kAssembly, kSecrete. Optimisation in log10(parameter)."""
import numpy as np, json, sys
from scipy.optimize import least_squares
from nguyen_port import *
FREE = [0, 2, 3, 4, 8, 9, 11, 12]; NAMES = ["kUptake","kNuclearEntry","kPlasmidDeg","kRepCapSyn","kDNArep","kBindRCplasmid","kBindCapsid","kPack"]
KW = dict(rtol=1e-6, atol=1e-3, method="BDF"); PTS = load(); K0 = kAll()
def expand(q):                                  # q = log10 of the 8 free parameters
    k = K0.copy(); p = 10**np.asarray(q)
    k[0], k[2], k[3] = p[0], p[1], p[2]; k[4] = k[5] = p[3]; k[8], k[9], k[11], k[12] = p[4], p[5], p[6], p[7]; return k
def res(q): return residuals(expand(q), PTS, **KW)
q0 = np.log10(K0[FREE]);
if __name__ == "__main__":
    r0 = res(q0); print("start (source values): SSR %.6f" % (r0**2).sum())
    best = None; rng = np.random.default_rng(20261026); starts = [q0] + [q0 + rng.normal(0, 0.4, 8) for _ in range(int(sys.argv[1]) if len(sys.argv) > 1 else 8)]
    for i, s in enumerate(starts):
        try: f = least_squares(res, s, method="trf", x_scale=1.0, diff_step=1e-4, xtol=1e-12, ftol=1e-12, gtol=1e-12, max_nfev=200)
        except Exception as e: print(i, "fail", e); continue
        ssr = (f.fun**2).sum(); print("start %d: SSR %.6f  nfev %d" % (i, ssr, f.nfev))
        if best is None or ssr < best[0]: best = (ssr, f.x, f)
    ssr, q, f = best; print("\nBEST SSR %.6f  RMSE %.6f" % (ssr, np.sqrt(ssr/31)))
    for n, a, b in zip(NAMES, K0[FREE], 10**q): print("  %-15s source %.4e -> fit %.4e (x%.3g)" % (n, a, b, b/a))
    json.dump(dict(names=NAMES, log10_theta=list(q), theta=list(10**q), ssr=ssr, rmse=float(np.sqrt(ssr/31)), solver=KW, n_points=31, seed=20261026, source_commit="4e7fb16c59ef2ca526618feca7fc8b25de79c65d"), open("fit8d_result.json", "w"), indent=1)
