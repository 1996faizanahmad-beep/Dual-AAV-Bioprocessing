#!/usr/bin/env python3
"""Repair suite for the dual-AAV manuscript (Vera QA items 1,3,4 + reproducibility).
Plain Python 3 (matplotlib optional for the figure). Writes CSVs to ./out.
Everything here is a CONDITIONAL / SCENARIO calculation, not experimental validation,
and not a reproduction of the original model code."""
import csv, os, random, math, argparse
from math import exp, sqrt

OUT = "out"; os.makedirs(OUT, exist_ok=True)
def dot(a, b): return sum(x*z for x, z in zip(a, b))
def write(name, header, rows):
    with open(os.path.join(OUT, name), "w", newline="") as f:
        w = csv.writer(f); w.writerow(header); w.writerows(rows)

# ---------------------------------------------------------------- ITEM 1: Study 6
def gaussian_update(F, y, sigma, mu0, sd0):
    prec = 1/sd0**2 + dot(F, F)/sigma**2
    var = 1/prec
    mu = var*(mu0/sd0**2 + dot(F, y)/sigma**2)
    return mu, sqrt(var)

def study6(eta_true, sigma, seed):
    F = [0.50, 0.675, 0.85]
    mu0, sd0 = 0.0815, 0.025                      # prior stated in manuscript
    # (a) Legacy stored observations: show what a stated likelihood implies
    y_old = [0.07970194165956616, 0.11773330974399461, 0.13742373454181414]
    rows = []
    for s in (0.002, 0.003003, 0.005, 0.010):
        mu, sd = gaussian_update(F, y_old, s, mu0, sd0)
        rows.append(["LEGACY_DIAGNOSTIC_ONLY_not_a_reproduced_result", s, "", round(mu, 6), round(sd, 6)])
    # (b) NEW fully specified demonstration: y_i = eta_true*F_i + N(0, sigma^2)
    rng = random.Random(seed)
    y_new = [eta_true*f + rng.gauss(0, sigma) for f in F]
    mu, sd = gaussian_update(F, y_new, sigma, mu0, sd0)
    # brute-force grid check of the closed form
    grid = [i*1e-5 for i in range(0, 40001)]
    lp = [-0.5*((e-mu0)/sd0)**2 - 0.5*sum((yi-e*f)**2 for f, yi in zip(F, y_new))/sigma**2 for e in grid]
    m = max(lp); w = [exp(v-m) for v in lp]; Z = sum(w)
    gm = sum(e*wi for e, wi in zip(grid, w))/Z
    gs = sqrt(sum((e-gm)**2*wi for e, wi in zip(grid, w))/Z)
    rows.append(["SYNTHETIC_DEMO_closed_form", sigma, seed, round(mu, 6), round(sd, 6)])
    rows.append(["SYNTHETIC_DEMO_grid_check", sigma, seed, round(gm, 6), round(gs, 6)])
    write("study6_posterior_documented.csv",
          ["case", "sigma_y", "seed", "posterior_mean", "posterior_sd"], rows)
    write("study6_new_demo_data.csv", ["F_full", "y_obs"], list(zip(F, y_new)))
    print("STUDY 6  model: y=eta*F + N(0,sigma^2); prior N(0.0815,0.025^2)")
    print(" legacy obs, OLS eta = %.5f" % (dot(F, y_old)/dot(F, F)))
    for r in rows[:4]: print("  legacy obs, sigma=%-8s -> post mean %.5f sd %.5f" % (r[1], r[3], r[4]))
    print(" NEW demo (eta_true=%g, sigma=%g, seed=%s): y=%s" % (eta_true, sigma, seed, [round(v, 5) for v in y_new]))
    print("  closed form %.5f +/- %.5f | grid %.5f +/- %.5f" % (mu, sd, gm, gs))
    try:
        import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
        xs = [i*1e-4 for i in range(0, 3001)]
        pdf = lambda x, m_, s_: exp(-0.5*((x-m_)/s_)**2)/(s_*sqrt(2*math.pi))
        plt.figure(figsize=(5.5, 3.6))
        plt.plot(xs, [pdf(x, mu0, sd0) for x in xs], label="Prior")
        plt.plot(xs, [pdf(x, mu, sd) for x in xs], label="Posterior (synthetic demo)")
        plt.axvline(eta_true, ls="--", c="k", lw=.8, label="eta_true (demo)")
        plt.title("SYNTHETIC DEMONSTRATION - not experimental data\n(y=eta*F+N(0,%g^2), seed %s)" % (sigma, seed), fontsize=8)
        plt.xlabel("eta"); plt.ylabel("density"); plt.legend(fontsize=8); plt.tight_layout()
        plt.savefig(os.path.join(OUT, "fig5c_regenerated.png"), dpi=200)
    except Exception as e:
        print(" (figure skipped:", e, ")")

# ---------------------------------------------------------------- ITEM 3: mass balance
def f_out(Fin, Rf, Rn): return Rf*Fin/(Rf*Fin + Rn*(1-Fin))
def mass_balance():
    Fin, Fo = 0.0309, 0.675
    ratio = Fin*(1-Fo)/((1-Fin)*Fo)
    print("\nMASS BALANCE  F_out=Rf*Fin/(Rf*Fin+Rn*(1-Fin))")
    print(" required Rn/Rf for 3.09%% -> 67.5%% : %.5f  (%.1f-fold)" % (ratio, 1/ratio))
    rows = []
    for sel in (1, 2, 5, 10, 20, 40, 65, 100):
        rows.append([sel, round(f_out(Fin, 1.0, 1.0/sel), 4)])
    write("mass_balance_selectivity_sweep.csv", ["fold_selectivity_Rf_over_Rn", "F_out_from_Fin_0.0309"], rows)
    for r in rows: print("  selectivity %5s-fold -> F_out %.4f" % tuple(r))

# ---------------------------------------------------------------- ITEM 4a: Poisson null
def p_both(m, r): return (1-exp(-m*r/(1+r)))*(1-exp(-m/(1+r)))
def poisson_null():
    print("\nINDEPENDENT-POISSON CO-DELIVERY NULL (relative to 1:1)")
    rows = []
    for r in (1, 2, 4):
        low = 4*r/(1+r)**2
        row = [r, round(low, 3)] + [round(p_both(m, r)/p_both(m, 1), 3) for m in (0.1, 1, 2, 5, 10)]
        rows.append(row)
        print("  A:B %d:1 low-dose %.3f | MOI 0.1/1/2/5/10: %s" % (r, low, row[2:]))
    write("poisson_null_relative_to_1to1.csv",
          ["ratio_A_to_B", "low_dose_limit", "MOI0.1", "MOI1", "MOI2", "MOI5", "MOI10"], rows)
    print("  manuscript h(r) ~ 0.318 (2:1), 0.135 (4:1) -> label as hypothesis (extra reconstitution/competition penalty)")

# ---------------------------------------------------------------- ITEM 4b: yield vs potency
def corr(a, b):
    ma, mb = sum(a)/len(a), sum(b)/len(b)
    c = sum((x-ma)*(z-mb) for x, z in zip(a, b))
    return c/sqrt(sum((x-ma)**2 for x in a)*sum((z-mb)**2 for z in b))
def yield_vs_potency(n=20000, seed=1):
    """ILLUSTRATIVE lognormal drivers (placeholders - replace with manuscript distributions)."""
    rng = random.Random(seed); ln = lambda s: math.exp(rng.gauss(0, s))
    ti_i, fn_i, ti_c, fn_c = [], [], [], []
    for _ in range(n):
        q, tr, aex = ln(.3), ln(.2), ln(.1)
        eta, Ff, qc = ln(.15), ln(.2), ln(.1)
        ti_i.append(q*tr*aex); fn_i.append(eta*Ff*qc)           # independent drivers
        z = rng.gauss(0, 1)                                     # shared latent process quality
        ti_c.append(q*tr*aex*math.exp(.3*z)); fn_c.append(eta*Ff*qc*math.exp(.3*z))
    print("\nYIELD vs POTENCY  corr(titre, function)")
    print("  independent draws (current design): %+.3f  (zero by construction)" % corr(ti_i, fn_i))
    print("  with shared latent quality factor : %+.3f  (coupling must be justified by data)" % corr(ti_c, fn_c))
    print("  Fixed dose  -> titre sets number of doses/cost, not delivered editing per dose.")
    print("  Yield-limited dose -> delivered editing ~ min(dose_target, titre*volume)*potency.")
    write("titre_function_correlation.csv", ["design", "pearson_r"],
          [["independent", round(corr(ti_i, fn_i), 4)], ["shared_latent", round(corr(ti_c, fn_c), 4)]])

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--eta_true", type=float, default=0.0815)   # prior-consistent demo; change if desired
    ap.add_argument("--sigma", type=float, default=0.003)
    ap.add_argument("--seed", type=int, default=20261026)
    a = ap.parse_args()
    study6(a.eta_true, a.sigma, a.seed); mass_balance(); poisson_null(); yield_vs_potency()
