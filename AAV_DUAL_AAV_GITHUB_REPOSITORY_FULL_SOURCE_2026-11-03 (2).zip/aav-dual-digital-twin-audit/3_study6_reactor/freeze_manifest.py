#!/usr/bin/env python3
"""Item: freeze run provenance. Usage: python3 freeze_manifest.py <repo_dir> [params.json]
Writes RUN_MANIFEST.json: file SHA-256s, python version, seed/params you supply.
Fill params.json with the exact 8D vector, residual definition, weights, transforms, seed."""
import hashlib, json, os, sys, platform, datetime
repo = sys.argv[1]; params = json.load(open(sys.argv[2])) if len(sys.argv) > 2 else {"TODO": "8D vector, residual objective, weights, obs transforms, seed"}
files = {}
for root, _, fs in os.walk(repo):
    if ".git" in root: continue
    for f in sorted(fs):
        p = os.path.join(root, f)
        files[os.path.relpath(p, repo)] = hashlib.sha256(open(p, "rb").read()).hexdigest()
json.dump({"created": datetime.datetime.utcnow().isoformat()+"Z", "python": platform.python_version(),
           "params": params, "files": files}, open("RUN_MANIFEST.json", "w"), indent=1)
print("wrote RUN_MANIFEST.json with", len(files), "files")
