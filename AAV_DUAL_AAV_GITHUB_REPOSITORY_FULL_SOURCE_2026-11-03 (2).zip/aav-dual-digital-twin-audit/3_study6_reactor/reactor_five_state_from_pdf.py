#!/usr/bin/env python3
"""Five-state Stage-1 model EXACTLY as written in the manuscript (Sec 2.2), plus reactor-structure variants.
PDF gives equations and constants. It does NOT give X0, G0, the horizon T or the response definition:
these are ASSUMED here (V_full at T) and varied to test robustness.
  dX/dt = [mu(G) - k_lysis*Vf] X ; dG/dt = D(Gfeed-G) - mu/Y*X ; dVg/dt = k_tr f(r) X - k_pack Vg C
  dC/dt = k_cap X - k_pack Vg C ; dVf/dt = k_pack Vg C ; mu = mumax G/(1+G) ; f(r)=1-2|r-0.5|
Modes: 'as_written' (only G diluted = perfusion with retention, no bleed) | 'chemostat' (all states diluted at D) |
       'perfusion_bleed' (G exchanged at D+B, X/Vg/C lost at bleed B, Vf harvested at B)."""
import numpy as np
from scipy.integrate import solve_ivp
P = dict(mumax=0.035, Y=0.55, ktr=0.85, kcap=1.02, kpack=0.012, klys=0.005, Gfeed=25.0)
def rhs(t, s, D, r, mode, B):
    X, G, Vg, C, Vf = [max(v, 0) for v in s]; mu = P["mumax"]*G/(1+G); f = 1-2*abs(r-0.5); pk = P["kpack"]*Vg*C
    dX = (mu-P["klys"]*Vf)*X; dG = D*(P["Gfeed"]-G)-mu/P["Y"]*X
    dVg = P["ktr"]*f*X-pk; dC = P["kcap"]*X-pk; dVf = pk
    if mode == "chemostat":
        dX -= D*X; dVg -= D*Vg; dC -= D*C; dVf -= D*Vf
    elif mode == "perfusion_bleed":
        dG += B*(P["Gfeed"]-G); dX -= B*X; dVg -= B*Vg; dC -= B*C; dVf -= B*Vf
    return [dX, dG, dVg, dC, dVf]
def resp(D, r, mode="as_written", B=0.0, T=96.0, X0=1.0, G0=25.0):
    s = solve_ivp(rhs, (0, T), [X0, G0, 0, 0, 0], args=(D, r, mode, B), method="LSODA", rtol=1e-8, atol=1e-10)
    return s.y[4, -1]
def sweep(mode, B=0.0, T=96.0, X0=1.0, G0=25.0):
    Ds = np.linspace(0, 0.12, 25); rs = np.linspace(0.30, 0.70, 25)
    Z = np.array([[resp(D, r, mode, B, T, X0, G0) for r in rs] for D in Ds]); i, j = np.unravel_index(Z.argmax(), Z.shape)
    return Ds[i], rs[j], Z[i, j], Z[:, j].copy(), Ds
if __name__ == "__main__":
    print("AS-WRITTEN model, assumed T/X0/G0 varied (response = Vf at T)")
    for T in (48, 96, 168, 336):
        for X0 in (0.3, 1.0):
            D, r, z, prof, Ds = sweep("as_written", T=T, X0=X0)
            print("  T=%3d X0=%.1f  optimum D=%.3f r=%.2f resp=%.3g %s" % (T, X0, D, r, z, "[UPPER BOUNDARY]" if D == 0.12 else "[LOWER/INTERIOR]" if D < 0.12 else ""))
    print("\nVariants at T=96 h, X0=1 (optimum over D at best r):")
    for mode, B in (("as_written", 0), ("chemostat", 0), ("perfusion_bleed", 0.005), ("perfusion_bleed", 0.02), ("perfusion_bleed", 0.05)):
        D, r, z, prof, Ds = sweep(mode, B)
        print("  %-16s B=%.3f  optimum D=%.3f r=%.2f resp=%.3g" % (mode, B, D, r, z))
    D, r, z, prof, Ds = sweep("as_written")
    print("\nas_written profile of Vf vs D at r=%.2f:" % r, [round(float(v), 1) for v in prof[::4]])
    # structure checks
    print("\nCLOSURE: integral of packaging flux = Vf  (D=0):")
    s = solve_ivp(rhs, (0, 96), [1, 25, 0, 0, 0], args=(0.0, 0.5, "as_written", 0), method="LSODA", rtol=1e-10, atol=1e-12, dense_output=True)
    ts = np.linspace(0, 96, 4001); y = s.sol(ts); flux = P["kpack"]*np.maximum(y[2], 0)*np.maximum(y[3], 0)
    print("  integral=%.6g  Vf(T)=%.6g" % (np.trapezoid(flux, ts), y[4, -1]))
