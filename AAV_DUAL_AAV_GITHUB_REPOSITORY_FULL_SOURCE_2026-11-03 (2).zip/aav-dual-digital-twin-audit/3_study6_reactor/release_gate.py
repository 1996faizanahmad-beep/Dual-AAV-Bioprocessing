#!/usr/bin/env python3
"""Pre-submission gate. Usage: python3 release_gate.py <manuscript_or_repo_dir>
Scans text files (.md .txt .tex .py .cff .csv .html) for placeholders, author notes and superseded numbers.
Exit code 1 if anything is found. It cannot prove correctness; it only blocks known leftovers."""
import os, re, sys
PLACEHOLDERS = [r"\[AUTHOR TO CONFIRM\]", r"\[ACCOUNT\]", r"\[CITE\]", r"\bTODO\b", r"\bTBD\b", r"\bFIXME\b", r"Payload Deliver\b(?!y)", r"\[EDIT"]
SUPERSEDED = {"0.0827": "old Study 6 posterior", "0.08265985": "old Study 6 posterior", "0.7208": "unreproduced SSR range", "0.7312 ": "unreproduced SSR range (check context)"}
hits = 0
for root, _, fs in os.walk(sys.argv[1]):
    if ".git" in root or "/out" in root: continue
    for f in fs:
        if not f.endswith((".md", ".txt", ".tex", ".py", ".cff", ".csv", ".html")) or f in ("release_gate.py",): continue
        p = os.path.join(root, f)
        for i, line in enumerate(open(p, errors="ignore"), 1):
            for pat in PLACEHOLDERS:
                if re.search(pat, line): print("PLACEHOLDER %s:%d %s" % (p, i, line.strip()[:90])); hits += 1
            for k, why in SUPERSEDED.items():
                if k in line: print("SUPERSEDED? (%s) %s:%d %s" % (why, p, i, line.strip()[:90])); hits += 1
print("gate: %d finding(s)" % hits); sys.exit(1 if hits else 0)
