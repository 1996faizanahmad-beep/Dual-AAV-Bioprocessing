#!/usr/bin/env python3
"""Reactor structure check: chemostat vs perfusion-with-retention, with explicit bleed.
STATES: X viable cells (1e6/mL), G glucose (g/L), V vector product (arb. units/mL).
PARAMETERS ARE ILLUSTRATIVE PLACEHOLDERS (mu_max 0.0494/h is the Nguyen 2021 value used in the project);
this demonstrates the BALANCE STRUCTURE and the boundary-maximum artifact. Replace rhs() with the
manuscript's ODE file to produce the repair figure. It is NOT the calibrated model.
Balances (total feed = D + B, permeate D, bleed B, constant volume):
  dX/dt = (mu - kd - kc*X) X - B X - (1-rho) D X          rho = cell retention (1 = full)
  dV/dt = qV X - kV V - (s_v D + B) V                       s_v = virion sieving to permeate
  dG/dt = (D + B)(Gfeed - G) - qG(mu) X
Chemostat: rho=0, s_v=1, B=0 -> everything diluted at D.
'Legacy' (glucose-only dilution): rho=1, s_v=0, B=0 -> X and V never removed."""
import csv, os
P = dict(mu_max=0.0494, Ks=0.5, kd=0.005, kc=0.0005, qV=5.0, kV=0.01, Gfeed=5.0, Yg=0.015, mG=0.002)
def rhs(s, D, B, rho, sv):
    X, G, V = s; mu = P["mu_max"]*G/(P["Ks"]+G)
    qG = mu/ (P["mu_max"]/P["Yg"]+1e-12) * 0 + P["Yg"]*mu/P["mu_max"] + P["mG"]*G/(P["Ks"]+G)  # g/L/h per 1e6 cells/mL
    dX = (mu - P["kd"] - P["kc"]*X)*X - B*X - (1-rho)*D*X
    dV = P["qV"]*X - P["kV"]*V - (sv*D + B)*V
    dG = (D+B)*(P["Gfeed"]-G) - qG*X
    return (dX, dG, dV)
def run(D, B, rho, sv, T=600.0, dt=0.1, s0=(0.5, 5.0, 0.0)):
    s = list(s0)
    for _ in range(int(T/dt)):
        k1 = rhs(s, D, B, rho, sv)
        k2 = rhs([a+0.5*dt*b for a, b in zip(s, k1)], D, B, rho, sv)
        k3 = rhs([a+0.5*dt*b for a, b in zip(s, k2)], D, B, rho, sv)
        k4 = rhs([a+dt*b for a, b in zip(s, k3)], D, B, rho, sv)
        s = [max(0.0, a+dt/6*(b+2*c+2*d+e)) for a, b, c, d, e in zip(s, k1, k2, k3, k4)]
    return s, rhs(s, D, B, rho, sv)
def tests():
    # T1: chemostat washout when D > mu_max
    (X, G, V), _ = run(0.08, 0, 0, 1)
    assert X < 1e-3, X
    # T2: chemostat steady state satisfies mu = kd + kc X + D
    D = 0.03; (X, G, V), d = run(D, 0, 0, 1); mu = P["mu_max"]*G/(P["Ks"]+G)
    assert abs(mu - P["kd"] - P["kc"]*X - D) < 1e-5, (mu, X)
    # T3: perfusion steady state: residual derivatives ~0
    (X, G, V), d = run(0.05, 0.01, 1, 1); assert max(abs(v) for v in d) < 1e-4, d
    # T4: glucose balance at steady state: (D+B)(Gfeed-G) = qG X
    print("  reactor self-tests passed (washout, chemostat balance, perfusion steady state)")
def sweep():
    os.makedirs("out", exist_ok=True); rows = []
    Ds = [round(0.005*i, 3) for i in range(1, 21)]
    configs = [("legacy_glucose_only_B0", 0.0, 1, 0), ("perfusion_B0.00", 0.0, 1, 1), ("perfusion_B0.01", 0.01, 1, 1),
               ("perfusion_B0.02", 0.02, 1, 1), ("perfusion_B0.04", 0.04, 1, 1), ("chemostat", 0.0, 0, 1)]
    print("\nSWEEP  productivity P=(s_v*D+B)*V at t=600h (legacy row: V/600h, no harvest); D grid 0.005-0.100 /h")
    for name, B, rho, sv in configs:
        best = (-1, None)
        for D in Ds:
            (X, G, V), _ = run(D, B, rho, sv)
            Pq = (sv*D + B)*V if (sv*D + B) > 0 else V/600.0   # legacy: no harvest -> in-reactor accumulation rate
            rows.append([name, D, B, round(X, 3), round(G, 3), round(V, 2), round(Pq, 3)])
            if Pq > best[0]: best = (Pq, D)
        edge = "BOUNDARY (grid max)" if best[1] == Ds[-1] else ("BOUNDARY (grid min)" if best[1] == Ds[0] else "interior")
        print("  %-24s optimum D=%.3f /h  P=%.2f  -> %s" % (name, best[1], best[0], edge))
    with open("out/reactor_sweep.csv", "w", newline="") as f:
        w = csv.writer(f); w.writerow(["config", "D", "B", "X", "G", "V", "productivity"]); w.writerows(rows)
if __name__ == "__main__":
    tests(); sweep()
