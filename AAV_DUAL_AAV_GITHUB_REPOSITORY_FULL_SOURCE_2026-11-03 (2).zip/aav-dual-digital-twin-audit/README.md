# Computational audit of a dual-AAV digital twin (reproducibility package)
Faizan Ahmad. Companion code, results and editable figures for the manuscript "A Mechanistic Digital Twin for Dual-AAV Bioprocessing and Multi-Gene Base-Editing Payload Delivery".
All analyses are computational; nothing here is experimental validation.

## What is in this repository
| Folder | Contents | Needs the private port? |
|---|---|---|
| `1_refit/` | Frozen 8D refit of the Nguyen 2021 21-state model: parameter vector, residual definition, singular values, weak-direction profiles, verification script | Re-running the fit: yes. Checking the frozen numbers: no |
| `2_release_risk/` | Study 11 release-rule risk with seeded noise and saved per-lot classification logic; 50-seed summary | No |
| `3_study6_reactor/` | Study 6 documented synthetic demonstration; five-state reactor built from the manuscript equations; pre-submission gate | No |
| `4_cleanroom_kit/` | Protocol and black-box acceptance tests for an independent open reimplementation of the Nguyen model | No |
| `figures/` | Editable vector figures (SVG with live text, PDF, 600 dpi PNG and TIFF), Source Data CSVs, all 13 manuscript figures as 300 ppi PNG (`manuscript_png_300ppi/`), and the scripts that reproduce the revised raster composites (`composites/`) | No |
| `tests/` | Public tests (CI) | No |
| `docs/` | Corrections log, figure inventory, availability statement, reproducibility notes, permission status | - |

## Quick start
    pip install -r requirements.txt
    python run_all.py            # regenerates figures/ and runs the tests (about 1 minute)

## Important limits
- The Python port of the Nguyen et al. model is NOT in this repository. The original code is CC BY-ND 4.0, which does not allow sharing adapted material. A permission request was drafted on 2026-10-26 but had not yet been sent at the time of this package build (docs/PERMISSION_STATUS.md). `1_refit/fetch_source.sh` downloads the authors' original files at the pinned commit `4e7fb16c59ef2ca526618feca7fc8b25de79c65d`; `1_refit/PORT_INTERFACE.md` documents what the scripts expect.
- The historical fit (SSR 0.731223) quoted in earlier drafts could not be reproduced (its parameter vector was never saved). The frozen refit here (SSR 0.668084) replaces it; see docs/CORRECTIONS_LOG.md.
- Only the figures listed in docs/FIGURE_INVENTORY.md as "regenerated here" are produced by this repository; the others come from the original manuscript repository.
- The 30,000 lot draws in `2_release_risk/` are retained for audit only; their provenance/hash match to the original archive must be established before using their derived metrics as manuscript evidence (see 2_release_risk/README_RELEASE_RISK.md).

## Licences
Original code: MIT (see LICENSE; author to confirm before the first public release). Results, tables, figures: CC BY 4.0. Upstream Nguyen et al. code and data: CC BY-ND 4.0, not redistributed.

## Citation
See CITATION.cff (add the repository URL, release tag and DOI after the first release).
