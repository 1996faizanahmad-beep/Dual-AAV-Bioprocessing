# Reproducibility notes
- Environment used: Python 3.12.3, numpy 2.4.4, scipy 1.17.1 (matplotlib, pandas, pillow current as of 2026-10-27).
- Deterministic from the stored inputs: figures (make_figures.py), the 50-seed Study 11 summary (seeds 1-50), Study 6 (seed 20261026), the five-state reactor, the frozen-fit checks.
- Needs the private port: the 8D refit (SSR 0.668084), profiles and Table 2 comparison. Random multistart (seed 1, SD 0.8 log10 around the source values) may differ on other library versions; refinement and profiles from the stored vector are deterministic (verified: SSR 0.668084 on BDF, Radau, LSODA; 0.668410 at the source-like tolerance 1e-2).
- Residual objective: 31 unweighted log10(model/observation) residuals: 12 total viral DNA (10, 24, 34, 46 h x 3), 10 total capsid (10, 10, 24, 24, 34, 34, 46, 46, 55, 55 h), 9 full virions (24, 34, 46 h x 3). 0.731223 / 0.153583^2 = 31.0 supports this definition.
- Source model checks (private port): total DNA and capsid within 0.1% of manuscript Table 2; full virions within 0.3% except 2.7% lower at 10 h; forward 46 h audit -14.3%, +44.8%, -6.3%.
- Local minima of the 8D objective found: 0.668, 0.687, 0.704, and a stalled basin near 2.2.
- The fit moves kPack about 1500-fold from its source value; it is a descriptive reduction, not a parameter estimate.
