# Permission status for the Python port (update as events occur)
Upstream: github.com/tamntnguyen/AAV-Triple-Transfection-Mechanistic-Model, commit 4e7fb16c59ef2ca526618feca7fc8b25de79c65d, licence CC BY-ND 4.0. Corresponding author of the article: Richard D. Braatz (braatz@mit.edu); repository owner: Tam N. T. Nguyen.
| Date | Event |
|---|---|
| 2026-10-26 | Request drafted (not yet sent). |
## Decision tree
1. Send the request to braatz@mit.edu and the repository owner (via GitHub contact or the article's author list).
2. Written YES (an email is enough): add nguyen_port.py to 1_refit/, cite the permission email in the README, run verify_reproduction.py, release.
3. NO, or no reply after 14 days: send the one-line follow-up below once; if still silent after 28 days, hand 4_cleanroom_kit/ to an independent implementer (do not do this yourself if you have read the .m files).
4. Meanwhile publish as built (port withheld); the manuscript's code statement must say the reimplementation is available after permission or via the clean-room version.
Follow-up (day 14): "Dear Prof. Braatz, I am following up on my message of [date] about publishing a Python reimplementation of your triple-transfection model with attribution. A one-line reply (yes / no / prefer private) would be very helpful for my submission timeline. Thank you, Faizan Ahmad."
