# Corrections log (executed 2026-10-26/27; each row cites the file that reproduces it)
| ID | Item (manuscript location) | Earlier value | Corrected / regenerated value | Evidence |
|---|---|---|---|---|
| C1 | Study 6 posterior (Sec 3.10, Fig. 5c) | eta posterior 0.0827 +/- 0.0025 from observations 0.080, 0.118, 0.137 | Observations are ~2x the y = eta F prediction (OLS eta 0.1653); replaced by a labelled synthetic demonstration, posterior 0.0841 +/- 0.0025 (seed 20261026) | 3_study6_reactor/aav_repair_suite.py; figures/Figure5c_study6_synthetic.* |
| C2 | 8D refit SSR (Sec 2.9, 3.6, 3.7, Table 4, Fig. 3, 12) | 0.731223 (vector not archived) | 0.668084 (frozen vector, 31 unweighted log10 residuals), RMSE 0.146803 | 1_refit/fit8d_FROZEN.json |
| C3 | 8D condition number | 4.09e4 | 6.00e3 (leading five: 17.0, was 14.8) | tests/test_public.py::test_frozen_fit_numbers |
| C4 | 14D SSR at source parameters | 1.7434 | 3.1144; 2.893 of it from the two 10 h capsid points | 1_refit/README_REFIT.md |
| C5 | 14D condition number and rank | 1.42e20; rank 12/14 "at 1e-6" | 6.4e21; rank 12/14 at 1e-12 but 10/14 at 1e-6; null directions: kProteinDegCap, and a kAssembly/kBindCapsid/kSecrete combination | figures/source_data/Fig3a_singular_values_14D.csv |
| C6 | Weak-direction profile baseline (Fig. 3e) | about 0.819; range 0.7208-0.7312 | Profiles regenerated from the frozen vector, baseline 0.668084; earlier profiles not reproduced and not shown | figures/source_data/Fig3e_profiles.csv |
| C7 | Source-model 10 h total capsid | not discussed | Overshoot 15.9-fold (9.32e9 vs 5.85e8 per mL); 2.1-fold after the refit | docs/REPRODUCIBILITY.md |
| C8 | Table 2 full virions at 10 h | 1.6005e7 | 1.557e7 (other entries within 0.1%) | independent port, private |
| C9 | Study 11 consumer risk (Sec 3.14, Fig. 8b,d) | 6.5/3.6% vs 6.4/4.8/3.8/2.8/1.9% (conflicting) | One set, 50-seed means: 6.4, 4.6, 3.7, 2.7, 1.9% (1,2,3,6,12 replicates); titre 45.8, fraction 32.2, product 35.9; acceptance share = 54.6% | 2_release_risk/study11_summary_50_noise_seeds.csv |
| C10 | Boundary maximum at D = 0.12 /h (Sec 3.2, Table 1) | reported as model "favouring increasing dilution" | Response varies by 0.04% across the dilution range; argmax at the sampled boundary of a flat surface; chemostat variant has optimum at D = 0 | 3_study6_reactor/reactor_five_state_from_pdf.py |
| C11 | 3.09% vs 67.5% (Sec 3.1, 3.3) | described as one trajectory | Separate scenarios; linking them would need R_nonfull/R_full = 0.01535 (about 65-fold full/non-full selectivity). Text uses 3.09% (source parameters); 3.70% under the refit | tests/test_public.py::test_poisson_null_and_mass_balance |
| C12 | A:B penalty h (Study 4) | presented without baseline | Independent-Poisson null 0.889 (2:1), 0.640 (4:1); manuscript h 0.318, 0.135 is a named hypothesis | same |
| C13 | Title | "...Payload Deliver" | "...Payload Delivery" | manuscript patch P01 |
| C14 | Methods headings | 2.15 and 2.16 swapped | swapped back | manuscript patch P10/P11 |
