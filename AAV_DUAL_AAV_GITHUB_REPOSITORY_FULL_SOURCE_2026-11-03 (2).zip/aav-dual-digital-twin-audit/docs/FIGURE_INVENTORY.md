# Figure inventory (manuscript: 12 main figures + graphical abstract)
Vector (editable) figures are produced by figures/make_figures.py (SVG with live text, PDF, 600 dpi PNG/TIFF, Source Data CSV). Final manuscript-ready PNGs of all 13 figures: figures/manuscript_png_300ppi/. Revised raster composites are reproducible from the manuscript PDF with figures/composites/ (pixel-identical).
| Manuscript figure | Format | Status |
|---|---|---|
| Fig. 3 (a-e) identifiability | Vector, regenerated here | Replaces the old Fig. 3 (Figure3_identifiability.*, per-panel Figure3a-e.svg) |
| Fig. 5 | Raster composite | Panel c replaced (synthetic demonstration); vector version of panel c: Figure5c_study6_synthetic.* |
| Fig. 8 | Raster composite | Panel b printed values and panel d replaced; vector version of b and d: Figure8bd_release_rules.* |
| Graphical abstract, Fig. 12 | Raster composite | Condition-number subtitle overlaid (6.4x10^21 -> 6.0x10^3); Fig. 12 caption letters corrected |
| Fig. 1, 2, 4, 6, 7, 9, 10, 11 | Raster, unchanged | Extracted at native resolution (about 1750 px wide). NOT vector: for journal-grade vector art rerun the original repository's run_all.py |
Limitations: replacement panels use a similar, not identical, typeface. Fig. 9c (radar, 1 - consumer risk) is unchanged within 0.2 percentage points.
