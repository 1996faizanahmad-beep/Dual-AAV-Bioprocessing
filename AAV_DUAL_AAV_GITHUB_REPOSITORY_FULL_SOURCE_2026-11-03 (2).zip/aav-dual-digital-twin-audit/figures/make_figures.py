#!/usr/bin/env python3
"""Editable (vector) versions of the figures regenerated in this audit: Fig. 3 (a-e), Fig. 5c, Fig. 8b/8d.
Outputs per figure: SVG (live text, svg.fonttype=none), PDF (TrueType 42), PNG and TIFF at 600 dpi, plus per-panel SVGs for Fig. 3 and Source Data CSVs.
Run from the repository root: python3 figures/make_figures.py"""
import os, sys, csv, random, io, numpy as np, pandas as pd
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
from PIL import Image
plt.rcParams.update({"svg.fonttype": "none", "pdf.fonttype": 42, "font.family": "sans-serif", "font.sans-serif": ["Arial", "Helvetica", "DejaVu Sans"], "axes.titlesize": 9, "axes.labelsize": 8, "xtick.labelsize": 7, "ytick.labelsize": 7, "legend.fontsize": 6.5})
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__))); OUT = os.path.join(ROOT, "figures"); SD = os.path.join(OUT, "source_data"); os.makedirs(SD, exist_ok=True)
def save(fig, name):
    for ext in ("svg", "pdf"): fig.savefig(os.path.join(OUT, f"{name}.{ext}"), bbox_inches="tight")
    buf = io.BytesIO(); fig.savefig(buf, format="png", dpi=600, bbox_inches="tight"); buf.seek(0); im = Image.open(buf).convert("RGB")
    im.save(os.path.join(OUT, f"{name}.png"), dpi=(600, 600)); im.save(os.path.join(OUT, f"{name}.tiff"), compression="tiff_lzw", dpi=(600, 600)); plt.close(fig)
# ------------------------------------------------------------------ Figure 3
R1 = os.path.join(ROOT, "1_refit"); J14 = np.load(os.path.join(R1, "J14_source.npy")); J8 = np.load(os.path.join(R1, "J8_fit.npy"))
S14 = np.linalg.svd(J14, compute_uv=False); _, S8, Vt = np.linalg.svd(J8, full_matrices=False); nrm = np.linalg.norm(J14, axis=0)
C = np.array([[J14[:, i] @ J14[:, j]/(nrm[i]*nrm[j]) for j in range(14)] for i in range(14)])
prof = pd.read_csv(os.path.join(R1, "weak_eta_profiles_REGENERATED.csv")); BASE = 0.668084
P8 = ["kUptake", "kNuclearEntry", "kPlasmidDeg", "kRepCapSyn", "kDNArep", "kBindRCplasmid", "kBindCapsid", "kPack"]
def pa(ax):
    ax.semilogy(range(1, 15), S14/S14[0], "o-", c="#e08214", ms=3, label="Full 14-parameter (source values)"); ax.semilogy(range(1, 9), S8/S8[0], "s-", c="#2166ac", ms=3, label="Source-constrained 8D (frozen fit)")
    ax.axhline(1e-6, ls="--", c="grey", lw=.7); ax.axhline(1e-12, ls=":", c="grey", lw=.7); ax.text(8.2, 1.6e-6, "10$^{-6}$", fontsize=6.5); ax.text(8.2, 1.6e-12, "10$^{-12}$", fontsize=6.5)
    ax.set_xlabel("Singular-value index"); ax.set_ylabel("Relative singular value"); ax.legend(); ax.set_title("a  Local sensitivity spectrum", loc="left")
def pb(ax):
    v = [S14[0]/S14[-1], S8[0]/S8[-1], S8[0]/S8[4]]; ax.bar(["14D", "8D", "Leading\n5D core"], v, color=["#e08214", "#2166ac", "#1b9e77"]); ax.set_yscale("log")
    [ax.text(i, x*1.5, "%.2g" % x, ha="center", fontsize=7) for i, x in enumerate(v)]; ax.set_ylabel("Condition number"); ax.set_title("b  Conditioning", loc="left")
def pc(ax):
    im = ax.imshow(C, cmap="RdBu_r", vmin=-1, vmax=1); ax.set_xticks(range(14)); ax.set_xticklabels(range(1, 15), fontsize=6); ax.set_yticks(range(14)); ax.set_yticklabels(range(1, 15), fontsize=6)
    ax.set_title("c  Column correlation of log-log sensitivities (14D)\nparameters 8 and 11 have near-zero columns", loc="left", fontsize=7); ax.figure.colorbar(im, ax=ax, fraction=.046)
def pd_(ax):
    im = ax.imshow(Vt, cmap="PuOr", vmin=-1, vmax=1); ax.set_xticks(range(8)); ax.set_xticklabels(["p%d" % i for i in range(1, 9)], fontsize=7); ax.set_yticks(range(8)); ax.set_yticklabels(["v1", "v2", "v3", "v4", "v5", "v6 (weak)", "v7 (weak)", "v8 (weak)"], fontsize=7)
    ax.set_title("d  Right-singular loadings (8D)\np1-p8: uptake, nuclear entry, plasmid deg., Rep/Cap synth.,\nDNA rep., Rep-plasmid binding, capsid binding, packaging", loc="left", fontsize=6.5); ax.figure.colorbar(im, ax=ax, fraction=.046)
def pe(ax):
    for v, col in ((8, "#1b9e77"), (7, "#e08214"), (6, "#2166ac")):
        d = prof[prof.weak_direction_v == v].sort_values("xi_log10_units"); ax.plot(d.xi_log10_units, d.SSR_after_reoptimisation, "o-", c=col, ms=3, label=f"Weak direction {v}")
    ax.axhline(BASE, ls="--", c="k", lw=.6); ax.set_xlabel("Step along weak singular direction (log$_{10}$ parameter units)"); ax.set_ylabel("SSR after re-optimisation"); ax.legend(); ax.set_title("e  Local profiles started at the frozen 8D fit (baseline SSR 0.668084)", loc="left")
panels = {"a": pa, "b": pb, "c": pc, "d": pd_, "e": pe}
fig = plt.figure(figsize=(11, 6.6)); gs = fig.add_gridspec(2, 3)
pa(fig.add_subplot(gs[0, 0])); pb(fig.add_subplot(gs[0, 1])); pc(fig.add_subplot(gs[0, 2])); pd_(fig.add_subplot(gs[1, 0])); pe(fig.add_subplot(gs[1, 1:])); fig.tight_layout(); save(fig, "Figure3_identifiability")
for k, f in panels.items():
    fg, ax = plt.subplots(figsize=(5.2, 3.6)); f(ax); fg.tight_layout(); fg.savefig(os.path.join(OUT, f"Figure3{k}.svg"), bbox_inches="tight"); plt.close(fg)
pd.DataFrame({"index": range(1, 15), "singular_value_14D": S14, "relative_14D": S14/S14[0]}).to_csv(os.path.join(SD, "Fig3a_singular_values_14D.csv"), index=False)
pd.DataFrame({"index": range(1, 9), "singular_value_8D": S8, "relative_8D": S8/S8[0]}).to_csv(os.path.join(SD, "Fig3a_singular_values_8D.csv"), index=False)
pd.DataFrame({"representation": ["14D", "8D", "leading_5D"], "condition_number": [S14[0]/S14[-1], S8[0]/S8[-1], S8[0]/S8[4]]}).to_csv(os.path.join(SD, "Fig3b_condition_numbers.csv"), index=False)
pd.DataFrame(C).to_csv(os.path.join(SD, "Fig3c_column_correlation_14D.csv"), index=False); pd.DataFrame(Vt, columns=P8).to_csv(os.path.join(SD, "Fig3d_loadings_8D.csv"), index=False); prof.to_csv(os.path.join(SD, "Fig3e_profiles.csv"), index=False)
# ------------------------------------------------------------------ Figure 5c (synthetic demonstration)
F = [0.50, 0.675, 0.85]; mu0, sd0, sig, eta_true, seed = 0.0815, 0.025, 0.003, 0.0815, 20261026
rng = random.Random(seed); y = [eta_true*f + rng.gauss(0, sig) for f in F]; prec = 1/sd0**2 + sum(f*f for f in F)/sig**2; var = 1/prec; mu = var*(mu0/sd0**2 + sum(f*v for f, v in zip(F, y))/sig**2); sd = var**.5
fig, ax = plt.subplots(figsize=(5.5, 3.6)); xs = np.linspace(0, 0.3, 3001); pdf = lambda x_, m, s: np.exp(-0.5*((x_-m)/s)**2)/(s*np.sqrt(2*np.pi))
ax.fill_between(xs, pdf(xs, mu0, sd0), alpha=.5, color="#9ecae1", label="Prior N(0.0815, 0.025$^2$)"); ax.fill_between(xs, pdf(xs, mu, sd), alpha=.6, color="#fdae6b", label=f"Posterior N({mu:.4f}, {sd:.4f}$^2$)")
ax.axvline(eta_true, ls="--", c="k", lw=.8, label="$\\eta_{true}$ (demonstration)"); ax.set_xlim(0, 0.2); ax.set_xlabel("$\\eta$"); ax.set_ylabel("Density"); ax.legend(); ax.set_title("c  SYNTHETIC DEMONSTRATION: not experimental data\ny = $\\eta$F + N(0, 0.003$^2$), F = 0.50, 0.675, 0.85; seed 20261026", loc="left", fontsize=8)
fig.tight_layout(); save(fig, "Figure5c_study6_synthetic")
pd.DataFrame({"F_full": F, "y_synthetic": y}).to_csv(os.path.join(SD, "Fig5c_synthetic_observations.csv"), index=False); pd.DataFrame([{"prior_mean": mu0, "prior_sd": sd0, "sigma_y": sig, "seed": seed, "posterior_mean": mu, "posterior_sd": sd}]).to_csv(os.path.join(SD, "Fig5c_posterior.csv"), index=False)
# ------------------------------------------------------------------ Figure 8 b, d (Study 11, 50 noise seeds)
S = pd.read_csv(os.path.join(ROOT, "2_release_risk", "study11_summary_50_noise_seeds.csv")).set_index("rule")
fig, ax = plt.subplots(1, 2, figsize=(8.5, 3.2)); kk = ["titre", "full_fraction", "titre_x_fraction", "function_x1", "function_x3"]; lab = ["Titre only", "Full fraction", "Titre x fraction", "Function x1", "Function x3"]; cols = ["#7f7f7f", "#e69f00", "#cc79a7", "#0072b2", "#009e73"]
m = [S.loc[k, "consumer_risk_mean_pct"] for k in kk]; s_ = [S.loc[k, "consumer_risk_sd_across_seeds"] for k in kk]
ax[0].barh(lab[::-1], m[::-1], xerr=s_[::-1], color=cols[::-1]); [ax[0].text(v+1, i, "%.1f%%" % v, va="center", fontsize=7) for i, v in enumerate(m[::-1])]
ax[0].set_xlabel("Accepted lots below specification (%)"); ax[0].set_title("b  Consumer risk at equal acceptance (54.6%)", loc="left")
R = [1, 2, 3, 6, 12]; mm = [S.loc["function_x%d" % r, "consumer_risk_mean_pct"] for r in R]; ss = [S.loc["function_x%d" % r, "consumer_risk_sd_across_seeds"] for r in R]
ax[1].errorbar(range(5), mm, yerr=ss, fmt="o-", c="#009e73", capsize=3); ax[1].axhline(5, ls="--", c="#e08214", lw=.8); ax[1].set_xticks(range(5)); ax[1].set_xticklabels(R); ax[1].set_xlabel("Functional-assay replicates per lot"); ax[1].set_ylabel("Consumer risk (%)")
ax[1].set_title("d  Replicates needed (mean $\\pm$ SD, 50 noise seeds)", loc="left"); ax[1].text(3.2, 5.2, "5% target", fontsize=6.5, color="#e08214"); fig.tight_layout(); save(fig, "Figure8bd_release_rules")
S.reset_index().to_csv(os.path.join(SD, "Fig8bd_consumer_risk.csv"), index=False)
print("figures written to", OUT)
