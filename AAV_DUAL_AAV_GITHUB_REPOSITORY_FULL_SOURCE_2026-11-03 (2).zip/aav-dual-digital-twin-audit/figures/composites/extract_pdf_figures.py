#!/usr/bin/env python3
"""Extract the raster figures embedded in the manuscript PDF at native resolution, compositing the soft masks onto white.
Usage: python3 extract_pdf_figures.py <manuscript.pdf> [out_dir=pdf_figures]   (needs poppler-utils: pdfimages)"""
import sys, os, subprocess, tempfile, numpy as np
from PIL import Image
pdf = sys.argv[1]; out = sys.argv[2] if len(sys.argv) > 2 else "pdf_figures"; os.makedirs(out, exist_ok=True)
names = {0: "GraphicalAbstract", 2: "Fig01", 4: "Fig02", 6: "Fig03", 8: "Fig04", 10: "Fig05", 12: "Fig06", 14: "Fig07", 16: "Fig08", 18: "Fig09", 20: "Fig10", 22: "Fig11", 24: "Fig12"}
with tempfile.TemporaryDirectory() as td:
    subprocess.check_call(["pdfimages", "-j", pdf, os.path.join(td, "img")])
    for n, lab in names.items():
        rgb = np.array(Image.open(os.path.join(td, "img-%03d.jpg" % n)).convert("RGB")).astype(float)
        a = np.array(Image.open(os.path.join(td, "img-%03d.ppm" % (n+1))).convert("L")).astype(float)[..., None]/255.0
        Image.fromarray((rgb*a+255*(1-a)).clip(0, 255).astype("uint8")).save(os.path.join(out, lab+"_original.png"), dpi=(300, 300))
print("extracted", len(names), "figures to", out)
