# Figure composites (revised manuscript figures built from the manuscript PDF)
The manuscript's raster figures were revised where numbers changed: Fig. 5c and 8d (panel replaced), Fig. 8b (four printed values overlaid), Graphical abstract and Fig. 12 (condition-number subtitle overlaid). Fig. 3 is fully regenerated as vector art (../make_figures.py).
    python3 extract_pdf_figures.py <manuscript.pdf> pdf_figures
    python3 recomposite.py          # Fig05_revised.png, Fig08_revised.png   (env: PDFIMG_DIR, OUT_DIR)
    python3 overlay_text.py         # GraphicalAbstract_revised.png, Fig12_revised.png
The composites are raster. Replacement panels use a similar but not identical typeface; for a fully consistent journal figure regenerate all panels with the original figure script.
