from PIL import Image, ImageDraw, ImageFont
import os
SRC=os.environ.get("PDFIMG_DIR","pdf_figures").rstrip("/")+"/"; OUT=os.environ.get("OUT_DIR","composite_out").rstrip("/")+"/"; os.makedirs(OUT, exist_ok=True)
F="/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf"
def fit(draw, text, target_w):
    lo, hi = 6, 60
    while hi-lo > 0.25:
        mid=(lo+hi)/2; w=draw.textlength(text, font=ImageFont.truetype(F, mid))
        lo, hi = (mid, hi) if w < target_w else (lo, mid)
    return lo
def edit(name, wipe, center, target_w, color, text, out):
    im=Image.open(SRC+name+"_original.png").convert("RGB"); d=ImageDraw.Draw(im); d.rectangle(wipe, fill=(255,255,255))
    size=fit(d, text, target_w); d.text(center, text, fill=color, font=ImageFont.truetype(F, size), anchor="mm"); im.save(OUT+out, dpi=(300,300)); return size
print("GA size", edit("GraphicalAbstract", (543,716,756,736), (649,724), 205, (40,40,40), "(8D condition 6.4\u00d710\u00b2\u00b9 \u2192 6.0\u00d710\u00b3)", "GraphicalAbstract_revised.png"))
print("Fig12 size", edit("Fig12", (696,131,890,152), (792,141), 180, (110,110,110), "8D condition: 6.4\u00d710\u00b2\u00b9 \u2192 6.0\u00d710\u00b3", "Fig12_revised.png"))
