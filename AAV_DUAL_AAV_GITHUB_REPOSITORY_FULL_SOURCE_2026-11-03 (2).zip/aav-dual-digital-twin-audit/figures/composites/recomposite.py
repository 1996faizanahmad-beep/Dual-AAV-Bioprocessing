import numpy as np, pandas as pd, random, io
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
from PIL import Image
plt.rcParams.update({"font.family": "sans-serif", "font.sans-serif": ["Liberation Sans", "Helvetica", "Arial", "DejaVu Sans"], "axes.spines.top": False, "axes.spines.right": False, "font.size": 5.4, "axes.titlesize": 6.4, "axes.labelsize": 6.0, "xtick.labelsize": 5.4, "ytick.labelsize": 5.4, "axes.linewidth": 0.6, "xtick.major.width": 0.6, "ytick.major.width": 0.6, "xtick.major.size": 2.5, "ytick.major.size": 2.5, "svg.fonttype": "none"})
DPI = 273
import os
ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
SRC = os.environ.get("PDFIMG_DIR", "pdf_figures").rstrip("/")+"/"; OUT = os.environ.get("OUT_DIR", "composite_out").rstrip("/")+"/"; os.makedirs(OUT, exist_ok=True)
S = pd.read_csv(os.path.join(ROOT, "2_release_risk", "study11_summary_50_noise_seeds.csv")).set_index("rule")
def fig_for(w, h): return plt.figure(figsize=(w/DPI, h/DPI), dpi=DPI)
def to_img(fig):
    b = io.BytesIO(); fig.savefig(b, format="png", dpi=DPI); plt.close(fig); b.seek(0); return Image.open(b).convert("RGB")
def paste(base, box, panel):
    x0, y0, x1, y1 = box; base.paste(Image.new("RGB", (x1-x0, y1-y0), "white"), (x0, y0)); base.paste(panel.resize((x1-x0, y1-y0), Image.LANCZOS), (x0, y0))
# ---- Fig 5c
def panel5c(w, h):
    F = [0.50, 0.675, 0.85]; mu0, sd0, sig, et = 0.0815, 0.025, 0.003, 0.0815; rng = random.Random(20261026); y = [et*f + rng.gauss(0, sig) for f in F]
    var = 1/(1/sd0**2 + sum(f*f for f in F)/sig**2); mu = var*(mu0/sd0**2 + sum(f*v for f, v in zip(F, y))/sig**2); sd = var**.5
    fig = fig_for(w, h); ax = fig.add_axes([0.20, 0.20, 0.77, 0.64]); xs = np.linspace(-0.01, 0.18, 2000); pdf = lambda m, s: np.exp(-0.5*((xs-m)/s)**2)/(s*np.sqrt(2*np.pi))
    ax.fill_between(xs, pdf(mu0, sd0), color="#a6d4f2", label="Prior"); ax.fill_between(xs, pdf(mu, sd), color="#e8a56d", label="Posterior"); ax.axvline(et, color="k", ls="--", lw=.6)
    ax.set_xlim(-0.01, 0.18); ax.set_ylim(-5, 175); ax.set_xticks([0, .05, .10, .15]); ax.set_xlabel("\u03b7"); ax.set_ylabel("Density"); ax.legend(loc="upper left", frameon=False)
    ax.text(0.97, 0.88, "SYNTHETIC data \u2013\ndemonstration only", transform=ax.transAxes, ha="right", va="top", color="#c8651b", style="italic", fontsize=5.2)
    ax.text(0.97, 0.47, "SD 0.025 \u2192 %.4f\n(10-fold contraction)" % sd, transform=ax.transAxes, ha="right", va="top", color="#444", fontsize=5.2)
    fig.text(0.0, 0.95, "c", fontsize=9, fontweight="bold", va="center"); fig.text(0.20, 0.93, "Bayesian updating of \u03b7", fontsize=6.4, va="center"); return to_img(fig)
# ---- Fig 8b
def panel8b(w, h):
    kk = ["titre", "full_fraction", "titre_x_fraction", "function_x1", "function_x3"]; lab = ["Titre only", "Full fraction", "Titre \u00d7 fraction", "Function \u00d71", "Function \u00d73"]; cols = ["#808080", "#E69F00", "#CC79A7", "#0072B2", "#009E73"]
    m = [S.loc[k, "consumer_risk_mean_pct"] for k in kk]; fig = fig_for(w, h); ax = fig.add_axes([0.27, 0.20, 0.69, 0.64]); ax.barh(range(5), m, color=cols, height=.8); ax.set_yticks(range(5)); ax.set_yticklabels(lab); ax.invert_yaxis()
    for i, v in enumerate(m): ax.text(v+1, i, "%.1f%%" % v, va="center", fontsize=5.4)
    ax.set_xlim(0, 62); ax.set_xlabel("Accepted lots below specification (%)"); ax.text(0.98, 0.04, "equal acceptance (54.6%); mean of 50 noise seeds", transform=ax.transAxes, ha="right", fontsize=4.6, color="#888", style="italic")
    fig.text(0.0, 0.95, "b", fontsize=9, fontweight="bold", va="center"); fig.text(0.27, 0.93, "Same result, as consumer risk", fontsize=6.4, va="center"); return to_img(fig)
# ---- Fig 8d
def panel8d(w, h):
    R = [1, 2, 3, 6, 12]; mm = [S.loc["function_x%d" % r, "consumer_risk_mean_pct"] for r in R]; ss = [S.loc["function_x%d" % r, "consumer_risk_sd_across_seeds"] for r in R]
    fig = fig_for(w, h); ax = fig.add_axes([0.20, 0.20, 0.77, 0.64]); ax.errorbar(R, mm, yerr=ss, fmt="o-", color="#009E73", ms=3.6, lw=1.2, capsize=0); ax.axhline(5, color="#c8651b", ls="--", lw=0.8)
    ax.text(12, 6.9, "mean of 50 noise seeds", color="#888", ha="right", fontsize=4.6, style="italic"); ax.text(12, 5.25, "5% target", color="#c8651b", ha="right", fontsize=5.2); ax.set_xticks(R); ax.set_ylim(0, 8); ax.set_xlim(0.4, 12.6); ax.set_xlabel("Functional-assay replicates per lot"); ax.set_ylabel("Consumer risk (%)")
    fig.text(0.0, 0.95, "d", fontsize=9, fontweight="bold", va="center"); fig.text(0.20, 0.93, "Replicates needed", fontsize=6.4, va="center"); return to_img(fig)

from PIL import ImageDraw, ImageFont
def overlay_8b(im):
    """Panel 8b: bars and labels are unchanged; only the printed values change (32.4->32.2, 36.0->35.9, 6.5->6.4, 3.6->3.7)."""
    a = np.array(im.convert("RGB")).astype(int); d = ImageDraw.Draw(im)
    new = ["45.8%", "32.2%", "35.9%", "6.4%", "3.7%"]; old = ["45.8%", "32.4%", "36.0%", "6.5%", "3.6%"]
    col = a[:, 700]; nonwhite = (col.sum(1) < 720); rows = []; start = None
    for y in range(30, 540):
        if nonwhite[y] and start is None: start = y
        if not nonwhite[y] and start is not None:
            if y-start > 25: rows.append((start, y-1))
            start = None
    assert len(rows) == 5, rows
    for (y0, y1), n, o in zip(rows, new, old):
        yc = (y0+y1)//2; barc = a[yc, 700]; x = 700
        while x < 1170 and np.abs(a[yc, x]-barc).sum() < 40: x += 1
        bar_end = x; seg = a[y0:y1+1, bar_end+4:bar_end+80].sum(2) < 330
        if not seg.any(): continue
        ys, xs = np.where(seg); bx0, bx1, by0, by1 = bar_end+4+xs.min(), bar_end+4+xs.max(), y0+ys.min(), y0+ys.max()
        if n == o: continue
        d.rectangle([bx0-2, by0-3, bx1+3, by1+3], fill="white"); h = by1-by0+1
        font = ImageFont.truetype("/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf", int(round(h/0.69)))
        d.text((bx0, yc), n, fill=(20, 20, 20), font=font, anchor="lm")
f5 = Image.open(SRC+"Fig05_original.png").convert("RGB"); b5 = (1170, 25, 1718, 492); paste(f5, b5, panel5c(b5[2]-b5[0], b5[3]-b5[1])); f5.save(OUT+"Fig05_revised.png", dpi=(273, 273))
f8 = Image.open(SRC+"Fig08_original.png").convert("RGB"); bb = (568, 25, 1168, 528); bd = (30, 655, 596, 1160)
overlay_8b(f8); paste(f8, bd, panel8d(bd[2]-bd[0], bd[3]-bd[1])); f8.save(OUT+"Fig08_revised.png", dpi=(273, 273)); print("ok")
