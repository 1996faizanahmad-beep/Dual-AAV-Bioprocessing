#!/usr/bin/env python3
"""Acceptance runner for a clean-room reimplementation. Usage: python3 run_acceptance.py <your_module_name> [data_dir]
Your module must define  simulate_observables(params: dict, times: list) -> dict with keys
'total_viral_DNA_per_mL','full_virions_per_mL','total_capsid_per_mL' (lists, same length as times).
Data: fetch the authors' unmodified Data/*.mat (see fetch step in README_CLEANROOM.md); data_dir defaults to ./Data.
SSR = sum of squared log10(model/observation) over 31 source points: 12 total DNA (10,24,34,46 h x3), 10 total capsid (10,10,24,24,34,34,46,46,55,55 h; first 10 rows), 9 full virions (24,34,46 h x3)."""
import sys, json, importlib, numpy as np, scipy.io as sio
mod = importlib.import_module(sys.argv[1]); dd = sys.argv[2] if len(sys.argv) > 2 else "Data"; T = json.load(open("ACCEPTANCE_TESTS.json")); ok = True
d1 = sio.loadmat(dd + "/E3_totalDNA_mL.mat"); d2 = sio.loadmat(dd + "/E3_mL_cap.mat"); d3 = sio.loadmat(dd + "/E3_gc_B_mL.mat")
a1 = [v for k, v in d1.items() if not k.startswith("__")][0]; a2 = [v for k, v in d2.items() if not k.startswith("__")][0][:-2]; a3 = [v for k, v in d3.items() if not k.startswith("__")][0]
pts = [("total_viral_DNA_per_mL", r[0], v) for r in a1 for v in r[1:]] + [("total_capsid_per_mL", r[0], r[1]) for r in a2] + [("full_virions_per_mL", r[0], v) for r in a3 for v in r[1:]]
for case in ("case_source_parameters", "case_frozen_8D_fit"):
    c = T[case]; times = sorted({p[1] for p in pts} | set(c["times_h"])); out = mod.simulate_observables(c["params"], times); idx = {t: i for i, t in enumerate(times)}
    for key in ("total_viral_DNA_per_mL", "full_virions_per_mL", "total_capsid_per_mL"):
        got = np.array([out[key][idx[t]] for t in c["times_h"]]); ref = np.array(c[key]); err = np.max(np.abs(got/ref-1)); good = err < T["rel_tol_observables"]; ok &= good
        print("%-4s %-22s %-25s max rel err %.2e" % ("PASS" if good else "FAIL", case, key, err))
    ssr = sum((np.log10(out[k][idx[t]]) - np.log10(v))**2 for k, t, v in pts); good = abs(ssr-c["SSR_log10_31pts"]) < T["abs_tol_SSR"]; ok &= good
    print("%-4s %-22s SSR %.4f (reference %.4f)" % ("PASS" if good else "FAIL", case, ssr, c["SSR_log10_31pts"]))
print("ACCEPTED" if ok else "NOT ACCEPTED"); sys.exit(0 if ok else 1)
