"""Tests that run WITHOUT the Python port (public CI). Run: pytest -q"""
import os, sys, json, random, importlib.util, numpy as np, pandas as pd
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
def load(rel, name):
    spec = importlib.util.spec_from_file_location(name, os.path.join(ROOT, rel)); m = importlib.util.module_from_spec(spec); sys.path.insert(0, os.path.dirname(os.path.join(ROOT, rel))); spec.loader.exec_module(m); return m
def test_study6_demo_and_legacy_ols():
    m = load("3_study6_reactor/aav_repair_suite.py", "suite"); F = [0.50, 0.675, 0.85]
    y_old = [0.07970194165956616, 0.11773330974399461, 0.13742373454181414]
    assert abs(sum(f*v for f, v in zip(F, y_old))/sum(f*f for f in F) - 0.16534) < 1e-4          # legacy observations imply eta ~ 0.1653
    rng = random.Random(20261026); y = [0.0815*f + rng.gauss(0, 0.003) for f in F]; mu, sd = m.gaussian_update(F, y, 0.003, 0.0815, 0.025)
    assert abs(mu - 0.0841) < 5e-4 and abs(sd - 0.0025) < 1e-4
def test_poisson_null_and_mass_balance():
    assert abs(4*2/(1+2)**2 - 0.889) < 1e-3 and abs(4*4/(1+4)**2 - 0.640) < 1e-3
    assert abs(0.0309*(1-0.675)/((1-0.0309)*0.675) - 0.01535) < 1e-5
def test_release_risk_reproduces_manuscript_pattern():
    m = load("2_release_risk/study11_release_rules.py", "s11"); d = pd.read_csv(os.path.join(ROOT, "2_release_risk/study7_process_to_product_mc.csv")); prev = (d.normalised_function >= 0.033).mean()
    assert abs(prev - 0.546) < 0.002
    out, _ = m.run(d, 20261027, prev); r = {k: v["consumer_risk"] for k, v in out.items()}
    assert 44.5 < r["titre"] < 47 and 31 < r["full_fraction"] < 33.5 and 34.5 < r["titre_x_fraction"] < 37.5
    assert 5.5 < r["function_x1"] < 7.5 and 3.0 < r["function_x3"] < 4.6 and r["function_x2"] < 5 < r["function_x1"]
def test_frozen_fit_numbers():
    j = json.load(open(os.path.join(ROOT, "1_refit/fit8d_FROZEN.json"))); assert abs(j["SSR"] - 0.668084) < 1e-6 and j["n_points"] == 31 and abs(j["log10_RMSE"] - 0.146803) < 1e-6
    S8 = np.linalg.svd(np.load(os.path.join(ROOT, "1_refit/J8_fit.npy")), compute_uv=False); assert 5.8e3 < S8[0]/S8[-1] < 6.2e3 and 16.5 < S8[0]/S8[4] < 17.5
    S14 = np.linalg.svd(np.load(os.path.join(ROOT, "1_refit/J14_source.npy")), compute_uv=False); rel = S14/S14[0]; assert (rel > 1e-12).sum() == 12 and (rel > 1e-6).sum() == 10
def test_five_state_response_is_flat_in_dilution():
    m = load("3_study6_reactor/reactor_five_state_from_pdf.py", "r5"); a = m.resp(0.0, 0.5); b = m.resp(0.12, 0.5)
    assert abs(b-a)/a < 1e-3 and b >= a                                                             # 0.04%: the "boundary maximum" is an argmax over a nearly flat surface
def test_licence_guard_no_port_or_upstream_files():
    bad = [os.path.join(r, f) for r, _, fs in os.walk(ROOT) for f in fs if f in ("nguyen_port.py", "model_params.mat") or f.endswith(".m") or r.endswith("/Data") and f.endswith(".mat")]
    assert not bad, f"Licensed/private files must not be committed: {bad}"
